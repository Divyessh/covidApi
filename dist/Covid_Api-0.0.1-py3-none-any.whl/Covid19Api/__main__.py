from .dataExtract import extract
from .fastApi import run

if __name__ == "__main__":
    extract()
    run()
